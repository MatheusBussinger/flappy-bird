const sprites = new Image();
sprites.src = "./sprites.png";

const som_punch = new Audio();
som_punch.src = "./som/punch.wav";

let animation_frame = 0;

const canvas = document.querySelector("#game-canvas");
const contexto = canvas.getContext("2d");

const flappyBird = {
  spriteX: 0,
  spriteY: 0,
  largura: 35,
  altura: 25,
  x: 10,
  y: 50,
  gravidade: 0.25,
  velocidade: 0,
  pulo: 4.6,
  frameAtual: 0,
  movimentos: [
    { spriteX: 0, spriteY: 0 },
    { spriteX: 0, spriteY: 26 },
    { spriteX: 0, spriteY: 52 },
    { spriteX: 0, spriteY: 26 },
  ],
  pula() {
    requestAnimationFrame(() => {
      flappyBird.velocidade = -flappyBird.pulo;
      flappyBird.atualizaFrame();
    });
  },
  desenha() {
    contexto.drawImage(
      sprites,
      flappyBird.spriteX,
      flappyBird.spriteY,
      flappyBird.largura,
      flappyBird.altura,
      flappyBird.x,
      flappyBird.y,
      flappyBird.largura,
      flappyBird.altura
    );
  },
  atualiza() {
    if (fazColisao()) {
      som_punch.play();
      telaAtiva = telaFinal;
      return;
    }
    flappyBird.velocidade += flappyBird.gravidade;
    flappyBird.y += flappyBird.velocidade;

    if (flappyBird.y + flappyBird.altura >= chao.y) {
      flappyBird.y = chao.y - flappyBird.altura;
      flappyBird.velocidade = 0;
    }
  },
  atualizaFrame() {
    if (animation_frame % 10 === 0) {
      flappyBird.frameAtual += 1;
      flappyBird.frameAtual %= flappyBird.movimentos.length;
      flappyBird.spriteX = flappyBird.movimentos[flappyBird.frameAtual].spriteX;
      flappyBird.spriteY = flappyBird.movimentos[flappyBird.frameAtual].spriteY;
    };
    const passou100Frames = (animation_frame % 100 === 0);
  },
  reset() {
    flappyBird.y = 50;
    flappyBird.velocidade = 0;
    flappyBird.frameAtual = 0;
  },
};

function fazColisao() {

  if (flappyBird.y + flappyBird.altura >= chao.y) {
    return true;
  }

  for (let cano of canos.pares) {
    const dentroX = flappyBird.x + flappyBird.largura > cano.x &&
                    flappyBird.x < cano.x + canos.largura;
    const bateuNoCanoCima = flappyBird.y < cano.top; 
    const bateuNoCanoBaixo = flappyBird.y + flappyBird.altura > cano.bottom; 
    if (dentroX && (bateuNoCanoCima || bateuNoCanoBaixo)) {
      return true;
    }
  }

  return false;
}



const chao = {
  spriteX: 0,
  spriteY: 609,
  largura: 225,
  altura: 114,
  x: 0,
  y: 380,
  desenha() {
    contexto.drawImage(
      sprites,
      chao.spriteX,
      chao.spriteY,
      chao.largura,
      chao.altura,
      chao.x,
      chao.y,
      chao.largura,
      chao.altura
    );
    contexto.drawImage(
      sprites,
      chao.spriteX,
      chao.spriteY,
      chao.largura,
      chao.altura,
      chao.x + 224,
      chao.y,
      chao.largura,
      chao.altura
    );
  },
  atualiza() {
    chao.x --;
    chao.x %= chao.largura / 2;
  },
};

const fundo = {
  spriteX: 390,
  spriteY: 0,
  largura: 278,
  altura: 205,
  x: 0,
  y: 280,
  desenha() {
    contexto.drawImage(
      sprites,
      fundo.spriteX,
      fundo.spriteY,
      fundo.largura,
      fundo.altura,
      fundo.x,
      fundo.y,
      fundo.largura,
      fundo.altura
    );
    contexto.drawImage(
      sprites,
      fundo.spriteX,
      fundo.spriteY,
      fundo.largura,
      fundo.altura,
      fundo.x + 275,
      fundo.y,
      fundo.largura,
      fundo.altura
    );
  },
  atualiza() {
    fundo.x -= 0.25;
    fundo.x %= fundo.largura / 1.69;
  },
};

const inicio = {
  spriteX: 135,
  spriteY: 0,
  largura: 173,
  altura: 152,
  x: 70,
  y: 70,
  desenha() {
    contexto.drawImage(
      sprites,
      inicio.spriteX,
      inicio.spriteY,
      inicio.largura,
      inicio.altura,
      inicio.x,
      inicio.y,
      inicio.largura,
      inicio.altura
    );
  },
};

const canos = {
  largura: 52,
  altura: 400,
  ceu: {
    spriteX: 52,
    spriteY: 169,
  },
  chao: {
    spriteX: 0,
    spriteY: 169,
  },
  pares: [],
  desenha() {
    const espacamento = 100;
    for (let i = 0; i < this.pares.length; i++) {
      const par = this.pares[i];
      const canoX = par.x;
      const canoY = par.y;
  
      contexto.drawImage(
        sprites,
        this.ceu.spriteX, this.ceu.spriteY,
        this.largura, this.altura,
        canoX, canoY,
        this.largura, this.altura
      );
  
      const canoChaoY = canoY + this.altura + espacamento;
      contexto.drawImage(
        sprites,
        this.chao.spriteX, this.chao.spriteY,
        this.largura, this.altura,
        canoX, canoChaoY,
        this.largura, this.altura
      );
  
      par.top = canoY + this.altura;
      par.bottom = canoChaoY;
    };
  },
  atualiza() {
    const espacamentoEntreCanos = 100;
  
    for (let i = 0; i < this.pares.length; i++) {
      const par = this.pares[i];
      par.x -= 2;
  
      par.top = par.y + canos.altura;
      par.bottom = par.y + canos.altura + espacamentoEntreCanos;

      if (!par.pontuado && par.x + this.largura < flappyBird.x) {
        score++;
        par.pontuado = true;
      }


      if (par.x + this.largura <= 0) {
        this.pares.splice(i, 1);
        i--;
      }
    }
  }
}


const medalhaBronze = {
  spriteX: 48,
  spriteY: 124,
  largura: 44,
  altura: 44,
  x: canvas.width / 2 - 86,
  y: canvas.height / 2 - 52,
  desenha() {
    contexto.drawImage (
      sprites,
      medalhaBronze.spriteX, medalhaBronze.spriteY,
      medalhaBronze.largura, medalhaBronze.altura,
      medalhaBronze.x, medalhaBronze.y,
      medalhaBronze.largura, medalhaBronze.altura
    );
  }
}


const medalhaPrata = {
  spriteX: 48,
  spriteY: 78,
  largura: 44,
  altura: 44,
  x: canvas.width / 2 - 86,
  y: canvas.height / 2 - 52,
  desenha() {
    contexto.drawImage(
      sprites,
      medalhaPrata.spriteX, medalhaPrata.spriteY,
      medalhaPrata.largura, medalhaPrata.altura,
      medalhaPrata.x, medalhaPrata.y,
      medalhaPrata.largura, medalhaPrata.altura,
    )
  }
}


const medalhaOuro = {
  spriteX: 0,
  spriteY: 124,
  largura: 44,
  altura: 44,
  x: canvas.width / 2 - 86,
  y: canvas.height / 2 - 52,
  desenha() {
    contexto.drawImage(
      sprites,
      medalhaOuro.spriteX, medalhaOuro.spriteY,
      medalhaOuro.largura, medalhaOuro.altura,
      medalhaOuro.x, medalhaOuro.y,
      medalhaOuro.largura, medalhaOuro.altura,
    )
  }
}


const medalhaPlatina = {
  spriteX: 0,
  spriteY: 78,
  largura: 44,
  altura: 44,
  x: canvas.width / 2 - 86,
  y: canvas.height / 2 - 52,
  desenha() {
    contexto.drawImage(
      sprites,
      medalhaPlatina.spriteX, medalhaPlatina.spriteY,
      medalhaPlatina.largura, medalhaPlatina.altura,
      medalhaPlatina.x, medalhaPlatina.y,
      medalhaPlatina.largura, medalhaPlatina.altura,
    )
  }
}


let score = 0;
let bestScore = 0;
let velocidadeCano = 2;
let intervaloCano = 1500;
let lastCanoTime = 0;
let opaciAni = 1;

const telaInicio = {
  desenha() {
    contexto.fillStyle = "#70c5ce";
    contexto.fillRect(0, 0, canvas.width, canvas.height);
    fundo.desenha();
    fundo.atualiza();
    chao.desenha();
    chao.atualiza();
    flappyBird.desenha();
    flappyBird.atualizaFrame();
    inicio.desenha();

    if (opaciAni > 0) {
      opaciAni -= 0.02;
      contexto.globalAlpha = opaciAni;
      contexto.fillStyle = "black";
      contexto.fillRect(0, 0, canvas.width, canvas.height);
    }
    contexto.globalAlpha = 1;
  },
  click() {
    telaAtiva = telaJogo;
    flappyBird.reset();
    opaciAni = 1;
    velocidadeCano = 2;
  },
};

const telaJogo = {
  desenha() {
    contexto.fillStyle = "#70c5ce";
    contexto.fillRect(0, 0, canvas.width, canvas.height);
    fundo.desenha();
    chao.desenha();
    canos.desenha();
    flappyBird.desenha();
    contexto.fillStyle = "white";
    contexto.font = "35px Arial";
    contexto.fillText(score, canvas.width / 2, 50);

  },
  click() {
    flappyBird.pula();
  },
};


const telaFinal = {
  spriteX: 134,
  spriteY: 152,
  largura: 226,
  altura: 722,
  x: 47,
  y: 100,
  desenha() {
    contexto.fillStyle = "#70c5ce";
    contexto.fillRect(0, 0, canvas.width, canvas.height);
    fundo.desenha();
    fundo.atualiza();
    chao.desenha();
    chao.atualiza();
    flappyBird.desenha();
    flappyBird.atualizaFrame();
    contexto.fillStyle = "white";
    contexto.font = "25px Arial";
    contexto.drawImage(
      sprites,
      telaFinal.spriteX,
      telaFinal.spriteY,
      telaFinal.largura,
      telaFinal.altura,
      telaFinal.x,
      telaFinal.y,
      telaFinal.largura,
      telaFinal.altura
    );
    if (bestScore <= score) {
      bestScore = score
    };
    if (score <= 10) {
      medalhaBronze.desenha()
    };
    if (score > 10 && score <= 20) {
      medalhaPrata.desenha()
    };
    if (score > 20 && score <= 30) {
      medalhaOuro.desenha()
    };
    if (score > 30 && score <= 40) {
      medalhaPlatina.desenha()
    };
    contexto.fillText(bestScore, canvas.width / 2 + 65, canvas.height / 2);
    contexto.fillText(score, canvas.width / 2 + 65, canvas.height / 2 - 42);
  },
  click() {
    canos.pares = [];
    score = 0;
    velocidadeCano = 2;
    intervaloCano = 1500;
    lastCanoTime = 0;
    telaAtiva = telaInicio;
    flappyBird.reset();
  },
};

let telaAtiva = telaInicio;

function mudaTelaAtiva() {
  telaAtiva.click();
}

window.addEventListener("click", mudaTelaAtiva);

function loop() {
  telaAtiva.desenha();

  if (telaAtiva === telaJogo) {
    fundo.atualiza();
    chao.atualiza();
    flappyBird.atualiza();
    flappyBird.atualizaFrame();
    canos.atualiza();

    if (animation_frame % 100 === 0) {
      const espacamento = 100; 
      const alturaMaximaCanoSuperior = canvas.height - chao.altura - espacamento; 
      

     const canoChaoY = alturaMaximaCanoSuperior + chao.altura;

     const alturaCanoTopo = Math.floor(Math.random() * alturaMaximaCanoSuperior - canoChaoY);

      canos.pares.push({
        x: canvas.width, 
        y: alturaCanoTopo, 
        top: alturaCanoTopo + canos.altura, 
        bottom: canoChaoY, 
        pontuado: false,
      });
    }    
  }

  animation_frame++;
  requestAnimationFrame(loop);
}



loop();
canos